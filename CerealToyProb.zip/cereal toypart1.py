import random
import matplotlib.pyplot as plt
from statistics import mean, median, mode, stdev

toys = list(range(1, 7))
collected = set()
count = 0
while len(collected) < 6:
    toy = random.choice(toys)
    collected.add(toy)
    count += 1
print(f"Total selections made to collect all toys in a single trial: {count}")

